﻿namespace Student_mangment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.studentmangment = new System.Windows.Forms.GroupBox();
            this.extra_curricular = new System.Windows.Forms.CheckBox();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.tirtir = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.courseslist = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Male = new System.Windows.Forms.RadioButton();
            this.StdIdzuu = new System.Windows.Forms.TextBox();
            this.StdAgezuu = new System.Windows.Forms.TextBox();
            this.Stdnamezuu = new System.Windows.Forms.TextBox();
            this.zuulabel3 = new System.Windows.Forms.Label();
            this.zuulabel2 = new System.Windows.Forms.Label();
            this.Zuulabel = new System.Windows.Forms.Label();
            this.studentmangment.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // studentmangment
            // 
            this.studentmangment.BackColor = System.Drawing.Color.Aqua;
            this.studentmangment.Controls.Add(this.extra_curricular);
            this.studentmangment.Controls.Add(this.ResultLabel);
            this.studentmangment.Controls.Add(this.tirtir);
            this.studentmangment.Controls.Add(this.button3);
            this.studentmangment.Controls.Add(this.courseslist);
            this.studentmangment.Controls.Add(this.button1);
            this.studentmangment.Controls.Add(this.groupBox2);
            this.studentmangment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentmangment.ForeColor = System.Drawing.Color.Black;
            this.studentmangment.Location = new System.Drawing.Point(23, 13);
            this.studentmangment.Name = "studentmangment";
            this.studentmangment.Size = new System.Drawing.Size(474, 712);
            this.studentmangment.TabIndex = 0;
            this.studentmangment.TabStop = false;
            this.studentmangment.Text = "Student Mangment";
            this.studentmangment.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // extra_curricular
            // 
            this.extra_curricular.AutoSize = true;
            this.extra_curricular.Location = new System.Drawing.Point(271, 414);
            this.extra_curricular.Name = "extra_curricular";
            this.extra_curricular.Size = new System.Drawing.Size(159, 24);
            this.extra_curricular.TabIndex = 11;
            this.extra_curricular.Text = "extra_curricular";
            this.extra_curricular.UseVisualStyleBackColor = true;
            // 
            // ResultLabel
            // 
            this.ResultLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ResultLabel.Location = new System.Drawing.Point(29, 547);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(380, 162);
            this.ResultLabel.TabIndex = 8;
            // 
            // tirtir
            // 
            this.tirtir.Location = new System.Drawing.Point(182, 501);
            this.tirtir.Name = "tirtir";
            this.tirtir.Size = new System.Drawing.Size(75, 36);
            this.tirtir.TabIndex = 9;
            this.tirtir.Text = "Clear";
            this.tirtir.UseVisualStyleBackColor = true;
            this.tirtir.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(294, 497);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 37);
            this.button3.TabIndex = 10;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // courseslist
            // 
            this.courseslist.FormattingEnabled = true;
            this.courseslist.ItemHeight = 20;
            this.courseslist.Items.AddRange(new object[] {
            "Java",
            "C#",
            "HTML &CSS3",
            "React"});
            this.courseslist.Location = new System.Drawing.Point(6, 382);
            this.courseslist.Name = "courseslist";
            this.courseslist.Size = new System.Drawing.Size(150, 104);
            this.courseslist.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(42, 504);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 8;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.Female);
            this.groupBox2.Controls.Add(this.Male);
            this.groupBox2.Controls.Add(this.StdIdzuu);
            this.groupBox2.Controls.Add(this.StdAgezuu);
            this.groupBox2.Controls.Add(this.Stdnamezuu);
            this.groupBox2.Controls.Add(this.zuulabel3);
            this.groupBox2.Controls.Add(this.zuulabel2);
            this.groupBox2.Controls.Add(this.Zuulabel);
            this.groupBox2.Location = new System.Drawing.Point(6, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(454, 323);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBoxStudentinfo";
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.Location = new System.Drawing.Point(299, 262);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(88, 24);
            this.Female.TabIndex = 7;
            this.Female.TabStop = true;
            this.Female.Text = "female";
            this.Female.UseVisualStyleBackColor = true;
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.Location = new System.Drawing.Point(155, 262);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(72, 24);
            this.Male.TabIndex = 6;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            // 
            // StdIdzuu
            // 
            this.StdIdzuu.Location = new System.Drawing.Point(212, 114);
            this.StdIdzuu.Name = "StdIdzuu";
            this.StdIdzuu.Size = new System.Drawing.Size(200, 26);
            this.StdIdzuu.TabIndex = 2;
            // 
            // StdAgezuu
            // 
            this.StdAgezuu.Location = new System.Drawing.Point(212, 195);
            this.StdAgezuu.Name = "StdAgezuu";
            this.StdAgezuu.Size = new System.Drawing.Size(200, 26);
            this.StdAgezuu.TabIndex = 4;
            // 
            // Stdnamezuu
            // 
            this.Stdnamezuu.Location = new System.Drawing.Point(212, 61);
            this.Stdnamezuu.Name = "Stdnamezuu";
            this.Stdnamezuu.Size = new System.Drawing.Size(200, 26);
            this.Stdnamezuu.TabIndex = 1;
            // 
            // zuulabel3
            // 
            this.zuulabel3.AutoSize = true;
            this.zuulabel3.Location = new System.Drawing.Point(36, 195);
            this.zuulabel3.Name = "zuulabel3";
            this.zuulabel3.Size = new System.Drawing.Size(115, 20);
            this.zuulabel3.TabIndex = 2;
            this.zuulabel3.Text = "Student Age:";
            // 
            // zuulabel2
            // 
            this.zuulabel2.AutoSize = true;
            this.zuulabel2.Location = new System.Drawing.Point(36, 120);
            this.zuulabel2.Name = "zuulabel2";
            this.zuulabel2.Size = new System.Drawing.Size(102, 20);
            this.zuulabel2.TabIndex = 1;
            this.zuulabel2.Text = "Student ID:";
            // 
            // Zuulabel
            // 
            this.Zuulabel.AutoSize = true;
            this.Zuulabel.Location = new System.Drawing.Point(36, 61);
            this.Zuulabel.Name = "Zuulabel";
            this.Zuulabel.Size = new System.Drawing.Size(129, 20);
            this.Zuulabel.TabIndex = 0;
            this.Zuulabel.Text = "Student Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 722);
            this.Controls.Add(this.studentmangment);
            this.Name = "Form1";
            this.Text = "Form1";
            this.studentmangment.ResumeLayout(false);
            this.studentmangment.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox studentmangment;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.TextBox StdIdzuu;
        private System.Windows.Forms.TextBox StdAgezuu;
        private System.Windows.Forms.TextBox Stdnamezuu;
        private System.Windows.Forms.Label zuulabel3;
        private System.Windows.Forms.Label zuulabel2;
        private System.Windows.Forms.Label Zuulabel;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.Button tirtir;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListBox courseslist;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox extra_curricular;
    }
}

